# Orchid Continuum Full Migration Toolkit

This toolkit moves all your files (SQLite `.db`, SQL dump `.sql`, CSV `.csv`, and images) into your Render PostgreSQL database.

---

## How to Use

1. Upload `orchid_migrate_full_toolkit.zip` into your Replit project.
2. Right-click and **Extract / Unzip** it.
3. Upload your orchid data files (or a single `.zip` of them) into the same Replit project.
4. Open the Replit Shell and run:

   ```bash
   pip install psycopg2-binary pandas
   python3 migrate.py
   ```

---

## Features

- Unzips any `.zip` files you upload into `import_data/`
- Backs up your Render DB before migration
- Imports SQLite `.db` → PostgreSQL
- Imports `.sql` dumps → PostgreSQL
- Imports `.csv` → PostgreSQL tables (named after file)
- Imports images (`.jpg`, `.png`) into a `photos` table
- Logs all steps to console

---

🎉 One zip, one script, everything migrated.
