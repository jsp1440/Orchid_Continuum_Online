import os
import psycopg2
import sqlite3
import pandas as pd
from datetime import datetime
import glob
import zipfile

# --- CONFIG ---
PG_CONN = "postgresql://orchid_user:4WVfquT9ZRvuc0PeHxyAvoGYPbdmIbq8@dpg-d390i5mmcj7s738lpqig-a.oregon-postgres.render.com/orchid_contnuum"
BACKUP_DIR = "backups"
IMPORT_DIR = "import_data"

# --- PREP FOLDERS ---
os.makedirs(BACKUP_DIR, exist_ok=True)
os.makedirs(IMPORT_DIR, exist_ok=True)

# --- UNZIP ANY ZIP FILES ---
for zip_file in glob.glob("*.zip"):
    print(f"[→] Unzipping {zip_file}")
    try:
        with zipfile.ZipFile(zip_file, 'r') as z:
            z.extractall(IMPORT_DIR)
        print(f"[✔] Extracted {zip_file} → {IMPORT_DIR}")
    except Exception as e:
        print(f"[✖] Failed to unzip {zip_file}: {e}")

# --- CONNECT TO POSTGRES ---
pg_conn = psycopg2.connect(PG_CONN)
pg_cur = pg_conn.cursor()

# --- BACKUP STEP ---
backup_file = os.path.join(BACKUP_DIR, f"backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.sql")
os.system(f"pg_dump '{PG_CONN}' > {backup_file}")
print(f"[✔] Backup saved to {backup_file}")

# --- LOOK INSIDE IMPORT_DIR FOR FILES ---
files = glob.glob(os.path.join(IMPORT_DIR, "**"), recursive=True)

# --- IMPORT SQL FILES ---
for sql_file in [f for f in files if f.endswith(".sql")]:
    print(f"[→] Importing SQL file: {sql_file}")
    with open(sql_file, "r") as f:
        sql_script = f.read()
    try:
        pg_cur.execute(sql_script)
        pg_conn.commit()
        print(f"[✔] {sql_file} imported")
    except Exception as e:
        print(f"[✖] Error in {sql_file}: {e}")
        pg_conn.rollback()

# --- IMPORT CSV FILES ---
for csv_file in [f for f in files if f.endswith(".csv")]:
    table_name = os.path.splitext(os.path.basename(csv_file))[0]
    print(f"[→] Importing CSV: {csv_file} → table: {table_name}")
    try:
        df = pd.read_csv(csv_file)
        cols = ",".join(df.columns)
        values = ",".join(["%s"] * len(df.columns))

        pg_cur.execute(f"DROP TABLE IF EXISTS {table_name}")
        create_query = "CREATE TABLE {} ({});".format(
            table_name, ",".join([f"{c} TEXT" for c in df.columns])
        )
        pg_cur.execute(create_query)

        for _, row in df.iterrows():
            pg_cur.execute(f"INSERT INTO {table_name} ({cols}) VALUES ({values})", tuple(row))
        pg_conn.commit()
        print(f"[✔] {csv_file} imported into {table_name}")
    except Exception as e:
        print(f"[✖] Error in {csv_file}: {e}")
        pg_conn.rollback()

# --- IMPORT SQLITE DB FILES ---
for db_file in [f for f in files if f.endswith(".db")]:
    print(f"[→] Importing SQLite DB: {db_file}")
    try:
        sqlite_conn = sqlite3.connect(db_file)
        sqlite_cur = sqlite_conn.cursor()
        sqlite_cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = sqlite_cur.fetchall()
        for (table_name,) in tables:
            df = pd.read_sql_query(f"SELECT * FROM {table_name}", sqlite_conn)
            cols = ",".join(df.columns)
            values = ",".join(["%s"] * len(df.columns))

            pg_cur.execute(f"DROP TABLE IF EXISTS {table_name}")
            create_query = "CREATE TABLE {} ({});".format(
                table_name, ",".join([f"{c} TEXT" for c in df.columns])
            )
            pg_cur.execute(create_query)

            for _, row in df.iterrows():
                pg_cur.execute(f"INSERT INTO {table_name} ({cols}) VALUES ({values})", tuple(row))
            pg_conn.commit()
            print(f"[✔] Imported table {table_name} from {db_file}")
        sqlite_conn.close()
    except Exception as e:
        print(f"[✖] Error importing {db_file}: {e}")
        pg_conn.rollback()

# --- IMPORT IMAGE FILES ---
pg_cur.execute("CREATE TABLE IF NOT EXISTS photos (filename TEXT, data BYTEA)")
for img_file in [f for f in files if f.endswith(".jpg") or f.endswith(".png")]:
    print(f"[→] Importing image: {img_file}")
    try:
        with open(img_file, "rb") as f:
            pg_cur.execute("INSERT INTO photos (filename, data) VALUES (%s, %s)", (os.path.basename(img_file), f.read()))
        pg_conn.commit()
        print(f"[✔] Imported {img_file} into photos table")
    except Exception as e:
        print(f"[✖] Error importing {img_file}: {e}")
        pg_conn.rollback()

pg_cur.close()
pg_conn.close()
print("[✔] Migration complete!")
