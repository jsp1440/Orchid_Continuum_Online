(function(){
  const el = document.getElementById('map-root');
  el.innerHTML = `<div class="card"><h3>World Map</h3><p>Embed map here (Leaflet/Mapbox).</p></div>`;
})();
