(function(){
  const el = document.getElementById('trivia-root');
  if(!el) return;
  el.innerHTML = `
    <div class="card">
      <h3>Orchid Trivia</h3>
      <p>Coming soon — wired to Continuum Q&A.</p>
    </div>`;
})();
