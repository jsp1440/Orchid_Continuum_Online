<!-- before -->
<img id="ood-img" src="/images/orchid.jpg" />

<!-- after -->
<img id="ood-img" src="/images/orchid.jpg?v=2025-09-13-01-10" />
