(function(){
  const el = document.getElementById('wx-root');
  el.innerHTML = `<div class="card">
    <h3>Weather ↔ Habitat</h3>
    <p>Compares local weather to native ranges (adapter hooks ready).</p>
  </div>`;
})();
